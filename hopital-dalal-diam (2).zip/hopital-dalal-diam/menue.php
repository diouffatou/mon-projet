<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <title> "menue"</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="veiwport" content="width=device-width,initial-scale=1.0">
        <link rel ="stylesheet" type="text/css" href="menue.css" >

    </head>
<body>
        <header>
        <div class="logo"> <span>W </span>'erral Diamm</div>
                <ul class="menue">
                    <li><a href="#">Acceuil</a></li>
                    <li><a href="#">Projets</a></li>
                    <li><a href="connexion.html">connexion</a></li>
                </ul>
         </div>
        </header>
       <!-- home -->
    <section class="home">
        <div class="home-infos">
            <h1>Services des patients</h1>
            <p> Nous fournissons la plus large gamme de services aux patients innovants accrédités</p>
            <a href="#">Embaucher un spécialiste</a>
        </div>
       </section>
       <!-- services -->
    <section class="Services">
        <h1 class="title">SERVICES MEDICAL</h1>
        <P class="sub-title">Notre centre offre à vous et à votre famille une gamme complète de services de santé</P>
        <div class="list-services">
            <div class="box">
            <h1>Ophetalmologue</h1>
            <p> Des soins sans rendez-vous, des rendez-vous le jour même aux visites en ligne avec Werral Diamm, nous prendrons bien soin de vous
                si vous avez une urgence.
                </P>
            </div>
            <div class="box">
            <h1>Dentiste</h1>
            <p> Des soins sans rendez-vous, des rendez-vous le jour même aux visites en ligne avec Werral Diamm, nous prendrons bien soin de vous
                si vous avez une urgence. </P>
            </div>
            <div class="box">
            <h1>Sage Femme</h1>
            <p> Des soins sans rendez-vous, des rendez-vous le jour même aux visites en ligne avec Werral Diamm, nous prendrons bien soin de vous
                si vous avez une urgence. </P>
            </div>
            <div class="box">
            <h1>Pediatre</h1>
            <p> Des soins sans rendez-vous, des rendez-vous le jour même aux visites en ligne avec Werral Diamm, nous prendrons bien soin de vous
                si vous avez une urgence.</P>
            </div>
            <div class="box">
            <h1>Géneraliste</h1>
            <p> Des soins sans rendez-vous, des rendez-vous le jour même aux visites en ligne avec Werral Diamm, nous prendrons bien soin de vous
                si vous avez une urgence.</P>
            </div>
            <div class="box">
            <h1>Génicologue</h1>
            <p> Des soins sans rendez-vous, des rendez-vous le jour même aux visites en ligne avec Werral Diamm, nous prendrons bien soin de vous
                si vous avez une urgence. </P>
            </div>
        </div> 
    </section>
   <!-- banner -->
    <section  class="banner"></section>
   <!-- our goal-->
    <section class="our-goal">
        <div class="left">
           <span>Nos Services</span>
           <h1>L'OBJECTIF SPÉCIFIQUE DE LA THÉRAPIE SERA DÉTERMINÉ PAR VOUS ET VOTRE THÉRAPEUTE</h1>
           <a href="prendre_un_RV.html">Prenez rendez-vous</a>
        </div>
    </section>  
      <!-- footer -->
    <footer>
        <h1 class="tite">Contacts</h1>
        <div class="Contact">
            <div class="class-form">
               <h2>Téléphone:785015180<br> 764844051</h2>
               <h4>Disponible 24H/24</h4>
               <form action="">
                    <input type="text" placeholder="Entrez votre Nom">
                    <input type="email" placeholder="Entrez votre  adress email">
                    <textarea placeholder="Entrez un message" cols="30" rows="10"></textarea>
                    <button>Soumettre</button>
                </form>
            </div>
            <div class="Adress">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15438.362205240555!2d-17.4588355081518!3d14.679162744083031!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xec17285e6967c53%3A0x6a775d2f8f2293c2!2sFann-Point%20E-Amiti%C3%A9%2C%20Dakar!5e0!3m2!1sfr!2ssn!4v1678297845394!5m2!1sfr!2ssn" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </footer>
</body>
</html>

